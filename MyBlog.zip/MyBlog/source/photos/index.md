﻿---
title: 光影留痕
type: picture
comments: true
---

<style>
.ImageGrid {
  width: 100%;
  max-width: 1040px;
  margin: 0 auto;
  text-align: center;
}
.card {
  overflow: hidden;
  transition: .3s ease-in-out;
  border-radius: 8px;
  background-color: #efefef;
  padding: 1.4px;
}
.ImageInCard img {
  padding: 0;
  border-radius: 8px;
}
@media (prefers-color-scheme: dark) {
  .card {background-color: #333;}
}
</style>

> 照片的主要拍摄工具是手机，有些照片简单调了一下滤镜和颜色。如果对拍摄的照片有什么建议，或者对某张照片感兴趣，欢迎留言评论。

<div class="ImageGrid"></div>